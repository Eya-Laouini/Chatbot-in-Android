package com.example.moveeasy;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        Button btnStartChat = findViewById(R.id.btnStartChat);
        Button btnLocalization = findViewById(R.id.btnLocalization);

        // Set up the button to start the chatbot activity
        btnStartChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the Chatbot Activity
                Intent intent = new Intent(MainActivity.this, Chatbot.class);
                startActivity(intent);
            }
        });

        // Set up the button for localization features
        btnLocalization.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the Localization Activity
                // Replace 'LocalizationActivity.class' with the actual class name for your localization feature
                //Intent intent = new Intent(Welcome.this, LocalizationActivity.class);
                //startActivity(intent);
            }
        });
    }
}
